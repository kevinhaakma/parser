#!/usr/bin/Rscript

args = commandArgs(trailingOnly=TRUE)

output = ""
count = 0
for (x in args){
  count = count + 1
  if(count == 1){
      output = paste(output, x, sep="")
  }
  else {
      output = paste(output, " ", x, sep="")
  }
}
print(output)

# install.packages("RMySQL")
library(RMySQL)

#wiebe R
con <- dbConnect(MySQL(), dbname="imdb", user="root", password="kevinhaakma")
query <- paste("SELECT COUNT(CASE WHEN actors.gender = 1 then 1 ELSE NULL END) as 'female', COUNT(CASE WHEN actors.gender = 0 then 1 ELSE NULL END) as 'male' from actors, roles2 where roles2.naam=actors.naam and roles2.movienaam LIKE '%",output,"%'",sep="")
values <- dbGetQuery(con, query)

invisible(jpeg('c:/temp/movieroles.jpg'))
barplot(c(values$male,values$female),names.arg=c("M","F"),xlab="gender",ylab="Count", main=output)
invisible(dev.off())
