#!/usr/bin/Rscript
args = commandArgs(trailingOnly=TRUE)

# install.packages("RMySQL")
library(RMySQL)

#kevin elon R
con <- dbConnect(MySQL(), dbname="imdb", user="root", password="kevinhaakma")
values <- dbGetQuery(con, "SELECT max(seasonnumber) as seasons, cijfer FROM ratings where seasonnumber != '0' and votes > 10 and cijfer != '0' GROUP BY naam")

invisible(dbDisconnect(con))

model = lm(cijfer~.,data=values)
input <- data.frame(seasons = as.numeric(args))
test <- predict(model, newdata = input)
cat(test)
