#!/usr/bin/Rscript
args = commandArgs(trailingOnly=TRUE)

# install.packages("RMySQL")
library(RMySQL)

#kevin elon R
con <- dbConnect(MySQL(), dbname="imdb", user="root", password="kevinhaakma")
values <- dbGetQuery(con, "select votes, cijfer from ratings where cijfer != '0'")

invisible(dbDisconnect(con))

model = lm(cijfer~.,data=values)
input <- data.frame(votes = as.numeric(args))
test <- predict(model, newdata = input)
cat(test)
